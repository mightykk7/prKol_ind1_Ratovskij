﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace pr_ratovskij
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private int currentPosition = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            string filePath = textBox1.Text;
            try
            {
                string formula = File.ReadAllText(filePath);
                formula = formula.Replace(" ", ""); // Удаляем пробелы
                int result = EvaluateFormula(formula);
                label1.Text = $"Результат: {result}";
                label1.Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private int EvaluateFormula(string formula)
        {
            if (currentPosition >= formula.Length)
            {
                MessageBox.Show("Ошибка: Неожиданный конец формулы.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 0; // Возвращаем нейтральное значение (например, 0)
            }
            char ch = formula[currentPosition];
            // Пропускаем запятые
            if (ch == ',')
            {
                currentPosition++;
                return EvaluateFormula(formula);
            }
            if (char.IsDigit(ch))
            {
                // Если цифра, возвращаем её как число
                currentPosition++;
                return int.Parse(ch.ToString());
            }
            else if (ch == 'm' || ch == 'p')
            {
                // Переходим к открывающей скобке
                currentPosition += 2; // Пропускаем оператор и открывающую скобку '('
                // Рекурсивно вычисляем первый операнд
                int a = EvaluateFormula(formula);
                // Рекурсивно вычисляем второй операнд
                int b = EvaluateFormula(formula);
                // Переходим за закрывающую скобку ')'
                currentPosition++;
                // Выполняем операцию
                switch (ch)
                {
                    case 'm':
                        return (a - b + 10) % 10; // m(a, b) = (a - b) mod 10
                    case 'p':
                        return (a + b) % 10; // p(a, b) = (a + b) mod 10
                    default:
                        MessageBox.Show("Ошибка: Неверная операция.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return 0; // Возвращаем нейтральное значение
                }
            }
            else
            {
                MessageBox.Show($"Ошибка: Некорректный символ '{ch}' в формуле.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 0; // Возвращаем нейтральное значение
            }
        }
    }
}
