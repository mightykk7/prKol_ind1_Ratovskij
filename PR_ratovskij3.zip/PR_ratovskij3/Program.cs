﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PR_ratovskij3
{
    class Program
    {
        static void Main(string[] args)
        {
            string filePath = "t.txt";
            try
            {
                if (!File.Exists(filePath))
                {
                    Console.WriteLine("Файл не найден.");
                    return;
                }
                using (StreamReader reader = new StreamReader(filePath))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        Stack<char> stack = new Stack<char>();
                        foreach (char c in line)
                        {
                            stack.Push(c);
                        }
                        while (stack.Count > 0)
                        {
                            Console.Write(stack.Pop());
                        }
                        Console.WriteLine();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }
            Console.ReadKey();
        }
    }
}
